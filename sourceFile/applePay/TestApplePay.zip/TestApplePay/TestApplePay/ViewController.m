//
//  ViewController.m
//  TestApplePay
//
//  Created by coderqi on 16/2/24.
//  Copyright © 2016年 coderqi. All rights reserved.
//

#import "ViewController.h"
#import <PassKit/PassKit.h>
#import <AddressBook/AddressBook.h>
@interface ViewController ()<PKPaymentAuthorizationViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)payAction:(UIButton *)sender {
    if([PKPaymentAuthorizationViewController canMakePayments]) {
        
        NSLog(@"支持支付");
        
        // 我们后面创建出来的支付页面就是根据这个request
        PKPaymentRequest *request = [[PKPaymentRequest alloc] init];
        // 商品目录
        PKPaymentSummaryItem *widget1 = [PKPaymentSummaryItem summaryItemWithLabel:@"麻辣烫"
                                                                            amount:[NSDecimalNumber decimalNumberWithString:@"0.01"]];
        
        PKPaymentSummaryItem *widget2 = [PKPaymentSummaryItem summaryItemWithLabel:@"肯德基"
                                                                            amount:[NSDecimalNumber decimalNumberWithString:@"0.01"]];
        
        PKPaymentSummaryItem *widget3 = [PKPaymentSummaryItem summaryItemWithLabel:@"海鲜大餐"
                                                                            amount:[NSDecimalNumber decimalNumberWithString:@"0.02"]];
        
        PKPaymentSummaryItem *widget4 = [PKPaymentSummaryItem summaryItemWithLabel:@"coderqi" amount:[NSDecimalNumber decimalNumberWithString:@"0.03"] type:PKPaymentSummaryItemTypeFinal];
        
        request.paymentSummaryItems = @[widget1, widget2, widget3, widget4];
//        request.countryCode = @"CN";
//        request.currencyCode = @"CNY";//人民币
        request.countryCode = @"US";
        request.currencyCode = @"USD";
        request.supportedNetworks = @[PKPaymentNetworkChinaUnionPay, PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
        
        // 这里填的是就是我们创建的merchat IDs
        request.merchantIdentifier = @"merchant.com.coderqi.applepay.pay";
        request.merchantCapabilities = PKMerchantCapabilityEMV;
        //增加邮箱及地址信息
        request.requiredBillingAddressFields = PKAddressFieldEmail | PKAddressFieldPostalAddress;
        // 根据request去创建支付页面
        PKPaymentAuthorizationViewController *paymentPane = [[PKPaymentAuthorizationViewController alloc] initWithPaymentRequest:request];
        
        // 设置代理
        paymentPane.delegate = self;
        
        if (!paymentPane) {
            NSLog(@"出问题了");
        } else {
            
            // 模态推出页面
            [self presentViewController:paymentPane animated:YES completion:nil];
        }
    } else {
        
        NSLog(@"该设备不支持支付");
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark ----支付状态
- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller
                       didAuthorizePayment:(PKPayment *)payment
                                completion:(void (^)(PKPaymentAuthorizationStatus status))completion{
    NSError *error;
    ABMultiValueRef addressMultiValue = ABRecordCopyValue(payment.billingAddress ,kABPersonAddressProperty);
    NSDictionary *addressDictionary = (__bridge_transfer NSDictionary *) ABMultiValueCopyValueAtIndex(addressMultiValue, 0);
    NSLog(@"%@",addressDictionary[@"State"]);
    NSData *json = [NSJSONSerialization dataWithJSONObject:addressDictionary options:NSJSONWritingPrettyPrinted error: &error];
    // ... Send payment token, shipping and billing address, and order information to your server ...
    PKPaymentAuthorizationStatus status; // From your server
    completion(status);
}
#pragma mark ----支付完成
- (void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller {
    
    // 支付完成后让支付页面消失
    [controller dismissViewControllerAnimated:YES completion:nil];
}
@end
