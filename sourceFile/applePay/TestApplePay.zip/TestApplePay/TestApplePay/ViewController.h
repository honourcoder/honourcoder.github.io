//
//  ViewController.h
//  TestApplePay
//
//  Created by coderqi on 16/2/24.
//  Copyright © 2016年 coderqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

