//
//  ViewController.m
//  ApplePayTestLesson
//
//  Created by coderqi on 16/3/1.
//  Copyright © 2016年 coderqi. All rights reserved.
//

#import "ViewController.h"
#import <PassKit/PassKit.h>
#import <AddressBook/AddressBook.h>

@interface ViewController ()<PKPaymentAuthorizationViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


//点击支付的相应事件
- (IBAction)payAction:(UIButton *)sender {
    
    // 订单请求对象
    PKPaymentRequest *request = [[PKPaymentRequest alloc]init];
    //商品订单信息对象
    PKPaymentSummaryItem *item1 = [PKPaymentSummaryItem summaryItemWithLabel:@"宝马车一辆" amount:[NSDecimalNumber decimalNumberWithString:@"100"]];
    PKPaymentSummaryItem *item2 = [PKPaymentSummaryItem summaryItemWithLabel:@"真皮座椅一个" amount:[NSDecimalNumber decimalNumberWithString:@"200"]];
    PKPaymentSummaryItem *item3 = [PKPaymentSummaryItem summaryItemWithLabel:@"自动雨刷两只" amount:[NSDecimalNumber decimalNumberWithString:@"50"]];
    request.paymentSummaryItems = @[item1,item2,item3];
    //指定国家地区编码
    request.countryCode = @"CN";
    //指定国家货币种类--人民币
    request.currencyCode = @"CNY";
    //指定支持的网上银行支付方式
    request.supportedNetworks = @[PKPaymentNetworkVisa,PKPaymentNetworkChinaUnionPay,PKPaymentNetworkMasterCard];
    //指定APP需要的商业ID
    request.merchantIdentifier = @"merchant.com.coderqi.pay.test";
    //指定支付的范围限制
    request.merchantCapabilities = PKMerchantCapabilityEMV;
    //指定订单接受的地址是哪里
    request.requiredBillingAddressFields = PKAddressFieldEmail | PKAddressFieldPostalAddress;
    
    //支付界面显示对象
    PKPaymentAuthorizationViewController *pvc = [[PKPaymentAuthorizationViewController alloc]initWithPaymentRequest:request];
    pvc.delegate = self;
    
    if (!pvc) {
        NSLog(@"出问题了，请注意检查");
        @throw  [NSException exceptionWithName:@"CQ_Error" reason:@"创建支付显示界面不成功" userInfo:nil];
    }else{
        [self presentViewController:pvc animated:YES completion:nil];
    }
}

//在支付的过程中进行调用，这个方法直接影响支付结果在界面上的显示
//payment 是代表的支付对象，支付相关的所有信息都存在于这个对象,1 token 2 address
//comletion 是一个回调Block块，block块传递的参数直接影响界面结果的显示。
-(void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didAuthorizePayment:(PKPayment *)payment completion:(void (^)(PKPaymentAuthorizationStatus))completion{
    /*
    NSError *error;
    ABMultiValueRef addressMultiValue = ABRecordCopyValue(payment.billingAddress ,kABPersonAddressProperty);
    NSDictionary *addressDictionary = (__bridge_transfer NSDictionary *) ABMultiValueCopyValueAtIndex(addressMultiValue, 0);
    //这里模拟取出地址里的每一个信息。
    NSLog(@"%@",addressDictionary[@"State"]);
    NSData *json = [NSJSONSerialization dataWithJSONObject:addressDictionary options:NSJSONWritingPrettyPrinted error: &error];
    // 这里需要将Token和地址信息发送到自己的服务器上，进行订单处理，处理之后，根据自己的服务器返回的结果调用completion()代码块，根据传进去的参数界面的显示结果会不同
    PKPaymentAuthorizationStatus status; // From your server
    completion(status);
    */
    //拿到token，
    PKPaymentToken *token = payment.token;
    //拿到订单地址
    NSString *city = payment.billingContact.postalAddress.city;
    NSLog(@"city:%@",city);
    ///在这里将token和地址发送到自己的服务器，有自己的服务器与银行和商家进行接口调用和支付将结果返回到这里
    //我们根据结果生成对应的状态对象，根据状态对象显示不同的支付结构
    //状态对象
    PKPaymentAuthorizationStatus status = PKPaymentAuthorizationStatusFailure;
    completion(status);
}

//当支付过程完成的时候进行调用
-(void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller{
    [controller dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
