//
//  AppDelegate.h
//  语音Lesson
//
//  Created by 齐路军 on 15/12/2.
//  Copyright © 2015年 齐路军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

