//
//  ViewController.h
//  语音Lesson
//
//  Created by 齐路军 on 15/12/2.
//  Copyright © 2015年 齐路军. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "iflyMSC/IFlyRecognizerViewDelegate.h"
//#import "iflyMSC/IFlyRecognizerView.h"
//#import "iflyMSC/IFlySpeechSynthesizerDelegate.h"
//#import "iflyMSC/IFlySpeechSynthesizer.h"
@interface ViewController : UIViewController


@end

